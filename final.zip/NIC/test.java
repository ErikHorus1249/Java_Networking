package NIC;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;

public class test {

    public static void main(String[] args) throws SocketException, IOException {
//        NetworkInterface nif = NetworkInterface.getByName("vmnet8");
//        Enumeration<InetAddress> nifAddress = nif.getInetAddresses();

//        try {
//            Enumeration interfaces = NetworkInterface.getNetworkInterfaces();
//            while (interfaces.hasMoreElements()) {
//                NetworkInterface ni = (NetworkInterface) interfaces.nextElement();
//                if(ni.isUp())System.out.println("up "+ni.getDisplayName());
//            }
//        } catch (SocketException ex) {
//            System.err.println("Error...");
//        }

//        Socket soc = new java.net.Socket();
//        soc.bind(new InetSocketAddress(nifAddress.nextElement(),0));
//        System.out.println(new InetSocketAddress(nifAddress.nextElement(),0));
//        System.out.println(new InetSocketAddress("localhost", 1249));
//        soc.connect(new InetSocketAddress("localhost", 1249));
//        System.out.println(nifAddress.nextElement());

//        System.out.println();
//        InetAddress id = new InetAddress(nifAddress.nextElement());
//        socket.bind(new InetAddress(nifAddress.nextElement(),0));

        NetworkInterface nif = NetworkInterface.getByName("wlp1s0");
        Enumeration<InetAddress> nifAddresses = nif.getInetAddresses();
        Socket soc = new java.net.Socket();
        soc.bind(new InetSocketAddress(nifAddresses.nextElement(), 0));
        soc.connect(new InetSocketAddress("localhost", 1249));
    }
}
