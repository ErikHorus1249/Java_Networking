/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MulticastChat;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author erik
 */
public class Server {

    private int port;
    private DatagramSocket socket;
    private List<User> users;
    private byte[] receiveData;
    private byte[] sendData;
    private DatagramPacket sendPacket;
    private DatagramPacket receivePacket;
    private String message;
    private InetAddress group;

    public Server(int port) throws UnknownHostException {
        this.port = port;
        
        this.users = new ArrayList<User>();
        this.group = InetAddress.getByName("224.2.2.3");
    }

    public static void main(String[] args) throws SocketException, UnknownHostException, IOException, InterruptedException {
        new Server(1249).run();
    }

    public void run() throws IOException {
        socket = new DatagramSocket(port) {
            protected void finalize() throws IOException {
                this.close();
            }
        };
        System.out.println("Server is runing ! port 1249");
        System.out.println("Luong nhan nickname : "+Thread.currentThread().getId());
        while (true) {

            message = receiveMessage();
            if (message.charAt(0) == '@') {
                String nicname = validateNickname(message);// chuan hoa ten client
                System.out.println(nicname);
                User newUser = new User(nicname, (InetSocketAddress) receivePacket.getSocketAddress());
                this.users.add(newUser);// them doi tuong nguoi dung vao list
                System.out.println(users);
                System.out.println("New Client: \"" + nicname + " " + newUser.getAddress());// thong bao co client moi
                sendClientNickname(newUser.getName(), newUser);
                multicastUsers();
//                sendMessage(users.toString());
            }else{
//                new Thread(new UserHandler(this, newUser)).start();// chay luong bat tin nhan moi cua nguoi dung
            }

        }
    }

    public void removeUser(User user) { // xoa nguoi dung khoi danh sach
        this.users.remove(user);
    }

    private String validateNickname(String nickname) {
        nickname = nickname.substring(1,nickname.length());
        nickname = nickname.replace(",", "");
        nickname = nickname.replace(" ", "_");
        return nickname;
    }

    private void sendClientNickname(String nickname, User user) throws IOException {
        sendData = new byte[1024];
        message = "nickname : @" + user.getName();
        sendData = message.getBytes();
        sendPacket = new DatagramPacket(sendData, sendData.length, user.getAddress());
        socket.send(sendPacket);
    }

    public String receiveMessage(User user) throws IOException {
        receiveData = new byte[1024];
        receivePacket = new DatagramPacket(receiveData, receiveData.length);
        socket.receive(receivePacket);
        return new String(receivePacket.getData());
    }

    public String receiveMessage() throws IOException {
        receiveData = new byte[1024];
        receivePacket = new DatagramPacket(receiveData, receiveData.length);
        socket.receive(receivePacket);
        return new String(receivePacket.getData());
    }

    public void broadcastMessagesAll(String msg, User userSender) { // gui tin nhan cho toan bo nguoi trong group
        for (User user : this.users) {
            message = userSender.getName() + " : " + msg;
            try {
                sendMessage(message);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void multicastUsers() throws IOException {// gui danh sach nguoi dang onlne cho cac nguoi dung khac
        System.out.println("danh sach : "+users.toString());
        for (User user : users) {
            sendMessage(users.toString());
        }
    }

    public void broadcastMessagesAll(User sender) { // gui tin nhan cho toan bo nguoi co nguoi thoat
        String msg = "!e " + sender.getName();
        for (User usr : this.users) {
            try {
                sendMessage(msg, usr);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    // private
    private void sendMessage(String msg, User user) throws IOException {
        sendData = msg.getBytes();
        sendPacket = new DatagramPacket(sendData, sendData.length, user.getAddress());
        socket.send(sendPacket);
    }

    // public
    private void sendMessage(String msg) throws IOException {
        sendData = msg.getBytes();
        sendPacket = new DatagramPacket(sendData, sendData.length, group, 1107);
        socket.send(sendPacket);
    }

    class UserHandler implements Runnable {

        private Server server; // khai bao server
        private User user;// khai bao nguoi dung

        public UserHandler(Server server, User user) throws IOException {
            this.server = server;
            this.user = user;
            this.server.multicastUsers();
        }

        public void run() {
            System.out.println("Mo luong cho user : "+user.getName()+" Id : "+Thread.currentThread().getId());
            while (!Thread.currentThread().isInterrupted()) {
                String message;
                try {
                    message = server.receiveMessage();
                    if (message != null) {
                        if (message.trim().toLowerCase().equals("!exit")) { // chat an danh
//                        server.broadcastMessages(user);
//                        server.removeUser(user);
//                        server.broadcastAllUsers();
                            System.out.println("Exit");
                        } else if (message.charAt(0) == '#') {
//                        user.changeColor(message);
//                        try {
//                            // update color for all other users
//                            this.server.broadcastAllUsers();
//                        } catch (IOException ex) {
//                            Logger.getLogger(UserHandler.class.getName()).log(Level.SEVERE, null, ex);
//                        }
                            System.out.println("Set color");
                        } else {
                            // update user list
                            System.out.println("Public");
                            server.broadcastMessagesAll(message, user);
                        }
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

        }
    }
}
