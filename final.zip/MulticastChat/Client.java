package MulticastChat;

import java.awt.Color;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erik
 */
public class Client {

    private String HOST;
    private int PORT;
    private String oldMsg = "";
    private String nickName;
    private Thread receive;
    private byte[] sendData;
    private byte[] receiveData;
    private DatagramPacket sendPacket;
    private DatagramPacket receivePacket;
    private MulticastSocket client;
    private String group; // dia chi IP cua group
    private Scanner sc;

    // init
    public Client(String host, int port) {
        this.HOST = host;
        this.PORT = port;
        this.sendData = new byte[1024];
        this.receiveData = new byte[1024];
        this.sc = new Scanner(System.in);
        this.group = "224.2.2.3";
    }

    public void run() {
        try {
            client = new MulticastSocket(1107);
            client.joinGroup(InetAddress.getByName(group));
            System.out.println("Luong chinh : " + Thread.currentThread().getId());
            connectAction();

            receive = new Receive();//tao luong nhan thong tin tu may chu
            receive.start();
//            while (sc.hasNext()) {
//                sendMessageAction();
//            }
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void connectAction() throws IOException {
        System.out.println("Nhap vao nich name : ");
        String nickname = sc.nextLine();
        sendMessageServer("@" + nickname);//gui nickname cho may chu
        System.out.println("Da gui nickname");
    }

    // gui tin nhan cho server
    private void sendMessageServer(String msg) throws IOException {
        sendData = null;
        sendData = msg.getBytes();
        this.sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName(HOST), PORT);
        client.send(sendPacket);
    }

    // gui tin nhan cho group
    private void sendMessageGroup(String msg) throws IOException {
        sendData = msg.getBytes();
        sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName(group), PORT);
        client.send(sendPacket);
    }

    public void sendExitMessage() throws IOException {
        String msg = "!exit";
//        sendMessageServer(msg);
    }

    public void sendMessageAction() {
        try {
            String message = sc.nextLine().trim();
            if (message.equals("")) {
                return;
            }
            sendMessageServer(message);
            System.out.println("da gui");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private String receiveMessage() throws IOException {
        String msg = null;
        receivePacket = new DatagramPacket(receiveData, receiveData.length);
        client.receive(receivePacket);
        msg = new String(receivePacket.getData());
        return msg;
    }

    public int getPort() {
        return this.PORT;
    }

    public String getHost() {
        return this.HOST;
    }

    class Receive extends Thread {

        public void run() {
            System.out.println("Luong nhan thong tin he thong : " + Thread.currentThread().getId());
            String message;
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    message = receiveMessage();

                    if (message != null) {
                        switch (message.charAt(0)) {
                            case '[':
                                message = message.substring(1, message.length() - 1);
                                ArrayList<String> ListUser = new ArrayList<String>(
                                        Arrays.asList(message.split(","))
                                );
                                System.out.println(ListUser);
                                String userListDis = "";
                                for (String user : ListUser) {
                                    userListDis += "\n#" + user;
                                }
//                                System.out.println(userListDis);
                                break;
                            case '!':
                                System.out.println("someone left");
                                break;
                            default:
                                //                            oldMsg += "\n"+message.trim();
                                System.out.println(message.trim());
                                break;
                        }
                    }
                } catch (IOException ex) {
                    System.err.println("Failed to parse incoming message");
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {
        new Client("localhost", 1249).run();
    }

}
