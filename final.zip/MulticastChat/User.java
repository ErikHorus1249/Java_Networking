/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MulticastChat;

import java.awt.Color;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import org.apache.commons.codec.cli.Digest;
import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author erik
 */
public class User {
    private String name;
    private InetSocketAddress address;
    private Color color;
    private ArrayList<String> oldMessage;
    private String hashCode;
    
    // init
    public User(String name, InetSocketAddress address, Color color){
        this.name = name;
        this.address = address;
        this.color = color;
        this.hashCode = DigestUtils.sha256Hex(name+address.toString());
    }
    
    public User(String name, InetSocketAddress address){
        this.name = name;
        this.address = address;
        this.hashCode = DigestUtils.sha256Hex(name+address.toString());
    }
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the group
     */
    public InetSocketAddress getAddress() {
        return address;
    }

    /**
     * @param group the group to set
     */
    public void setGroup(InetSocketAddress address) {
        this.address = address;
    }

    /**
     * @return the color
     */
    public Color getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * @return the oldMessage
     */
    public ArrayList<String> getOldMessage() {
        return oldMessage;
    }

    /**
     * @return the hashCode
     */
    public String getHashCode() {
        return hashCode;
    }

    /**
     * @param hashCode the hashCode to set
     */
    public void setHashCode(String hashCode) {
        this.hashCode = hashCode;
    }
    
    public String toString(){
        return getName();
    }
   
}
