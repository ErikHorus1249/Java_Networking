package serverUDP;

import serverSide.*;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.awt.Color;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

public class serverControl {

    private int port;
    private List<User> clients;
    private DatagramSocket server;
    private byte[] receiveData;
    private byte[] sendData;
    private DatagramPacket sendPacket;
    private DatagramPacket receivePacket;
    private String message;

    public static void main(String[] args) throws IOException {
        new serverControl(1429).run();
    }

    public serverControl(int port) {
        this.port = port;
        this.clients = new ArrayList<User>();
        // luong du lieu
        this.receiveData = new byte[1024];
        this.sendData = new byte[1024];
    }

    public void run() throws IOException {
        server = new DatagramSocket(port);

        System.out.println("Port 1429 is now open.");

        while (true) {

            String nickname = receiveMessage();

            if (nickname != null) {
                System.out.println("OK");
            }
            System.out.println(nickname);

            validateNickname(nickname);// chuan hoa ten client
            User newUser = new User((InetSocketAddress) receivePacket.getSocketAddress(), nickname);// tao moi doi tuong nguoi dung
            this.clients.add(newUser);// them doi tuong nguoi dung vao list

            // thong bao co client moi
            System.out.println("New Client: \"" + nickname + "\"\n\t     Host:" + receivePacket.getAddress());

            sendClientNickname(nickname, newUser);

            System.out.println(receivePacket.getAddress() + " " + receivePacket.getPort());
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, receivePacket.getAddress(), receivePacket.getPort());
            server.send(sendPacket);
            new Thread(new UserHandler(this, newUser)).start();// chay luong bat tin nhan moi cua nguoi dung
        }
    }

    public void removeUser(User user) { // xoa nguoi dung khoi danh sach
        this.clients.remove(user);
    }

    private String validateNickname(String nickname) {
        nickname = nickname.replace(",", "");
        nickname = nickname.replace(" ", "_");
        return nickname;
    }

    private void sendClientNickname(String nickname, User user) throws IOException {
        message = "Server give your nickname : " + user.toString();
        System.out.println(message);
        sendData = message.getBytes();
        sendPacket = new DatagramPacket(sendData, sendData.length, user.getclientAddr());
        server.send(sendPacket);
    }

    private void sendMessage(String msg, User user) throws IOException {
        sendData = msg.getBytes();
        sendPacket = new DatagramPacket(sendData, sendData.length, user.getclientAddr());
        server.send(sendPacket);
    }

    public boolean isAlive(User user) throws IOException {
        System.out.println("check");
        String msg = "?alive";
        sendMessage(msg, user);
        if (receiveMessage(user).trim().toLowerCase().equals("!alive")) {
            return true;
        }
        return false;
    }

    public String receiveMessage(User user) throws IOException {
        receivePacket = new DatagramPacket(receiveData, receiveData.length);
        server.receive(receivePacket);
        return new String(receivePacket.getData());
    }

    public String receiveMessage() throws IOException {
        receivePacket = new DatagramPacket(receiveData, receiveData.length);
        server.receive(receivePacket);
        return new String(receivePacket.getData());
    }

    public void broadcastMessages(String msg, User userSender) { // gui tin nhan cho toan bo nguoi trong group
        for (User client : this.clients) {
            message = userSender.getNickname() + " : " + msg;
            try {
                sendMessage(message, client);
            } catch (IOException ex) {
                Logger.getLogger(serverControl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void broadcastMessages(User user) { // gui tin nhan cho toan bo nguoi co nguoi thoat
        String msg = "!e "+user.getNickname();
        for (User client : this.clients) {
            try {
                sendMessage(msg, client);
            } catch (IOException ex) {
                Logger.getLogger(serverControl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void broadcastAllUsers() throws IOException {// gui danh sach nguoi dang onlne cho cac nguoi dung khac
        for (User client : this.clients) {
            System.out.println(this.clients.toString());
            sendMessage(this.clients.toString(), client);
        }
    }

    public void sendMessageToUser(String msg, User userSender, String user) {// gui tin nhan an danh rieng tu
        boolean find = false;
        for (User client : this.clients) {
            if (client.getNickname().equals(user) && client != userSender) {
                find = true;
                userSender.getOutStream().println(userSender.toString() + " -> " + client.toString() + ": " + msg);
                System.out.println(userSender.toString() + " : " + msg);
                client.getOutStream().println(userSender.toString() + " : " + msg);
            }
        }
        if (!find) {
            userSender.getOutStream().println(userSender.toString() + " -> (<b>no one!</b>): " + msg);
        }
    }
}

class UserHandler implements Runnable {

    private serverControl server; // khai bao server
    private User user;// khai bao nguoi dung

    public UserHandler(serverControl server, User user) throws IOException {
        this.server = server;
        this.user = user;
        this.server.broadcastAllUsers();
    }

    public void run() {

        while (true) {
            String message;
            try {
                message = server.receiveMessage();
                if (message != null) {
                    if (message.trim().toLowerCase().equals("!exit")) { // chat an danh
                        server.broadcastMessages(user);
                        server.removeUser(user);
                        server.broadcastAllUsers();
                    } else if (message.charAt(0) == '#') {
                        user.changeColor(message);
                        try {
                            // update color for all other users
                            this.server.broadcastAllUsers();
                        } catch (IOException ex) {
                            Logger.getLogger(UserHandler.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        // update user list
                        System.out.println("Public");
                        server.broadcastMessages(message, user);
                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(UserHandler.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        
    }

}

class User {

    private static int nbUser = 0;
    private int userId;
    private PrintStream streamOut;
    private InputStream streamIn;
    private String nickname;
    private InetSocketAddress clientAddr;
    private String color;

    // constructor
    public User(InetSocketAddress clientAddr, String name) throws IOException {

        this.clientAddr = clientAddr;
        this.nickname = name;
        this.userId = nbUser;
        this.color = ColorInt.getColor(this.userId);
        nbUser += 1;
    }

    // change color user
    public void changeColor(String hexColor) {
        // check if it's a valid hexColor
        Pattern colorPattern = Pattern.compile("#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})");
        Matcher m = colorPattern.matcher(hexColor);
        if (m.matches()) {
            Color c = Color.decode(hexColor);
            // if the Color is too Bright don't change
            double luma = 0.2126 * c.getRed() + 0.7152 * c.getGreen() + 0.0722 * c.getBlue(); // per ITU-R BT.709
            if (luma > 160) {
                this.getOutStream().println("<b>Color Too Bright</b>");
                return;
            }
            this.color = hexColor;
            this.getOutStream().println("<b>Color changed successfully</b> " + this.toString());
            return;
        }
        this.getOutStream().println("<b>Failed to change color</b>");
    }

    // getteur
    public PrintStream getOutStream() {
        return this.streamOut;
    }

    public InputStream getInputStream() {
        return this.streamIn;
    }

    public String getNickname() {
        return this.nickname;
    }

    public InetSocketAddress getclientAddr() {
        return this.clientAddr;
    }

    // print user with his color
    public String toString() {

//        return "<u><span style='color:"+ this.color
//                +"'>" + this.getNickname() + "</span></u>";
        return this.getNickname();
    }
}

class ColorInt {

    public static String[] mColors = {
        "#3079ab", // dark blue
        "#e15258", // red
        "#f9845b", // orange
        "#7d669e", // purple
        "#53bbb4", // aqua
        "#51b46d", // green
        "#e0ab18", // mustard
        "#f092b0", // pink
        "#e8d174", // yellow
        "#e39e54", // orange
        "#d64d4d", // red
        "#4d7358", // green
    };

    public static String getColor(int i) {
        return mColors[i % mColors.length];
    }
}
